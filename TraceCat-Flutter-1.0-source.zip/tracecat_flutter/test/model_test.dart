import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:tracecat_flutter/main.dart';

void main() {
  test('project view survives JSON round trip', () {
    final project = TraceProject(
      id: 'test',
      name: 'Test project',
      imagePath: '/tmp/image.png',
      created: 1,
      modified: 2,
      view: TraceView()
        ..centerX = 0.25
        ..centerY = 0.75
        ..opacity = 0.6
        ..anchorReferences = [
          AnchorReference(size: 1, bytes: Uint8List.fromList([123])),
          AnchorReference(size: 1, bytes: Uint8List.fromList([124])),
          AnchorReference(size: 1, bytes: Uint8List.fromList([125])),
          AnchorReference(size: 1, bytes: Uint8List.fromList([126])),
        ],
    );

    final decoded = TraceProject.fromJson(
      jsonDecode(jsonEncode(project.toJson())) as Map<String, dynamic>,
    );

    expect(decoded.name, 'Test project');
    expect(decoded.view.centerX, 0.25);
    expect(decoded.view.centerY, 0.75);
    expect(decoded.view.opacity, 0.6);
    expect(decoded.view.anchorReferences?.last.bytes.single, 126);
  });
}
