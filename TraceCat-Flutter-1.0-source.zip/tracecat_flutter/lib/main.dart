import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  final cameras = await availableCameras();
  runApp(TraceCatApp(cameras: cameras));
}

class TraceCatApp extends StatelessWidget {
  const TraceCatApp({super.key, required this.cameras});

  final List<CameraDescription> cameras;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TraceCat',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.amber,
        scaffoldBackgroundColor: const Color(0xFF05070A),
        useMaterial3: true,
      ),
      home: TraceCatHome(cameras: cameras),
    );
  }
}

class TraceCatHome extends StatefulWidget {
  const TraceCatHome({super.key, required this.cameras});

  final List<CameraDescription> cameras;

  @override
  State<TraceCatHome> createState() => _TraceCatHomeState();
}

class _TraceCatHomeState extends State<TraceCatHome>
    with WidgetsBindingObserver {
  final ImagePicker _picker = ImagePicker();
  final ProjectStore _store = ProjectStore();

  CameraController? _camera;
  TraceProject? _project;
  List<TraceProject> _projects = const [];
  ui.Image? _templateInfo;
  Size _stageSize = Size.zero;

  bool _cameraStarting = false;
  bool _traceMode = false;
  bool _torchOn = false;
  bool _focusLocked = false;
  bool _anchorMode = false;
  bool _busy = false;
  final List<Offset> _anchorTaps = [];

  String _status = 'Import an image to begin';
  Timer? _statusTimer;

  Offset? _gestureStartFocal;
  Offset? _gestureStartCenter;
  double _gestureStartScale = 1;
  double _gestureStartRotation = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_initialize());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _statusTimer?.cancel();
    _camera?.dispose();
    _templateInfo?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) return;
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      unawaited(controller.dispose());
      _camera = null;
    } else if (state == AppLifecycleState.resumed) {
      unawaited(_startCamera());
    }
  }

  Future<void> _initialize() async {
    await _store.initialize();
    _projects = await _store.loadAll();
    final current = await _store.loadCurrent();
    if (current != null) await _setProject(current);
    if (mounted) setState(() {});
  }

  void _setStatus(String message, {Duration hold = const Duration(seconds: 2)}) {
    _statusTimer?.cancel();
    if (mounted) setState(() => _status = message);
    if (hold > Duration.zero) {
      _statusTimer = Timer(hold, () {
        if (!mounted) return;
        setState(() {
          _status = _project == null
              ? 'Import an image to begin'
              : (_project!.view.pinned ? 'Image pinned' : 'Ready');
        });
      });
    }
  }

  Future<void> _setProject(TraceProject project) async {
    _templateInfo?.dispose();
    _templateInfo = null;
    final file = File(project.imagePath);
    if (!await file.exists()) return;
    final bytes = await file.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    _templateInfo = frame.image;
    codec.dispose();
    _project = project;
    await _store.setCurrent(project.id);
    if (mounted) setState(() {});
  }

  CameraDescription? get _backCamera {
    if (widget.cameras.isEmpty) return null;
    return widget.cameras.firstWhere(
      (camera) => camera.lensDirection == CameraLensDirection.back,
      orElse: () => widget.cameras.first,
    );
  }

  Future<void> _startCamera() async {
    if (_cameraStarting || _backCamera == null) return;
    _cameraStarting = true;
    if (mounted) setState(() {});
    try {
      await _camera?.dispose();
      final controller = CameraController(
        _backCamera!,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      await controller.initialize();
      await controller.setFlashMode(FlashMode.off);
      await controller.setFocusMode(FocusMode.auto);
      _camera = controller;
      _torchOn = false;
      _focusLocked = false;
      _setStatus('Camera running');
    } on CameraException catch (error) {
      _setStatus(_cameraMessage(error), hold: Duration.zero);
    } catch (error) {
      _setStatus('Camera error: $error', hold: Duration.zero);
    } finally {
      _cameraStarting = false;
      if (mounted) setState(() {});
    }
  }

  String _cameraMessage(CameraException error) {
    switch (error.code) {
      case 'CameraAccessDenied':
      case 'CameraAccessDeniedWithoutPrompt':
        return 'Allow camera access in Android settings';
      case 'CameraAccessRestricted':
        return 'Camera access is restricted on this phone';
      default:
        return 'Camera error: ${error.description ?? error.code}';
    }
  }

  Future<void> _refocus({bool lockAfter = true}) async {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) {
      _setStatus('Start the camera first');
      return;
    }
    try {
      _setStatus('Refocusing camera...', hold: Duration.zero);
      await controller.setFocusMode(FocusMode.auto);
      try {
        await controller.setFocusPoint(const Offset(0.5, 0.5));
      } catch (_) {}
      await Future<void>.delayed(const Duration(milliseconds: 1100));
      if (lockAfter) {
        await controller.setFocusMode(FocusMode.locked);
        _focusLocked = true;
        _setStatus('Camera focused and locked');
      } else {
        _focusLocked = false;
      }
    } on CameraException catch (error) {
      _focusLocked = false;
      _setStatus('Focus control unavailable: ${error.description ?? error.code}');
    }
    if (mounted) setState(() {});
  }

  Future<void> _lockCurrentFocus({bool showMessage = true}) async {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) return;
    try {
      await controller.setFocusMode(FocusMode.locked);
      _focusLocked = true;
      if (showMessage) _setStatus('Current focus locked');
    } on CameraException {
      _focusLocked = false;
      if (showMessage) _setStatus('This phone controls focus automatically');
    }
    if (mounted) setState(() {});
  }

  Future<void> _toggleTorch() async {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) return;
    try {
      final wanted = !_torchOn;
      await controller.setFlashMode(wanted ? FlashMode.torch : FlashMode.off);
      setState(() => _torchOn = wanted);
      _setStatus(wanted ? 'Flashlight on' : 'Flashlight off');
    } on CameraException {
      _setStatus('Flashlight control is unavailable');
    }
  }

  Future<void> _importImage() async {
    final picked = await _picker.pickImage(
      source: ImageSource.gallery,
      requestFullMetadata: false,
    );
    if (picked == null) return;
    try {
      final project = await _store.createFromImport(File(picked.path));
      _projects = await _store.loadAll();
      await _setProject(project);
      _fitImage(showMessage: false);
      await _saveCurrent(showMessage: false);
      _setStatus('Image imported');
    } catch (error) {
      _setStatus('Import failed: $error', hold: const Duration(seconds: 4));
    }
  }

  void _fitImage({bool showMessage = true}) {
    final project = _project;
    final image = _templateInfo;
    if (project == null || image == null || _stageSize.isEmpty) return;
    final aspect = image.width / image.height;
    final maxWidth = _stageSize.width * 0.82;
    final maxHeight = _stageSize.height * 0.72;
    var width = maxWidth;
    if (width / aspect > maxHeight) width = maxHeight * aspect;
    project.view
      ..centerX = 0.5
      ..centerY = 0.5
      ..baseWidth = width / _stageSize.width
      ..scale = 1
      ..rotation = 0
      ..anchorQuad = null
      ..anchorReferences = null;
    if (mounted) setState(() {});
    if (showMessage) _setStatus('Image fit to screen');
  }

  void _resetView() {
    final project = _project;
    if (project == null) return;
    project.view
      ..pinned = false
      ..opacity = 0.48;
    _fitImage(showMessage: false);
    _setStatus('View reset');
  }

  Future<void> _saveCurrent({bool showMessage = true}) async {
    final project = _project;
    if (project == null) return;
    await _store.save(project);
    _projects = await _store.loadAll();
    if (showMessage) _setStatus('Project saved');
  }

  Future<void> _enterTraceMode() async {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) {
      _setStatus('Start the camera before tracing');
      return;
    }
    final project = _project;
    if (project == null) {
      _setStatus('Import an image before tracing');
      return;
    }
    project.view.pinned = true;
    await _saveCurrent(showMessage: false);

    // This only changes focus mode. It never changes the image transform,
    // preview size, system UI mode, or screen layout.
    await _lockCurrentFocus(showMessage: false);
    if (!mounted) return;
    setState(() => _traceMode = true);
  }

  void _exitTraceMode() {
    setState(() => _traceMode = false);
    _setStatus('Controls restored');
  }

  void _startGesture(ScaleStartDetails details) {
    final project = _project;
    if (project == null || project.view.pinned || project.view.anchorQuad != null) {
      return;
    }
    _gestureStartFocal = details.focalPoint;
    _gestureStartCenter = Offset(
      project.view.centerX * _stageSize.width,
      project.view.centerY * _stageSize.height,
    );
    _gestureStartScale = project.view.scale;
    _gestureStartRotation = project.view.rotation;
  }

  void _updateGesture(ScaleUpdateDetails details) {
    final project = _project;
    if (project == null ||
        project.view.pinned ||
        project.view.anchorQuad != null ||
        _gestureStartFocal == null ||
        _gestureStartCenter == null ||
        _stageSize.isEmpty) {
      return;
    }
    final center = _gestureStartCenter! +
        (details.focalPoint - _gestureStartFocal!);
    setState(() {
      project.view.centerX = center.dx / _stageSize.width;
      project.view.centerY = center.dy / _stageSize.height;
      project.view.scale = (_gestureStartScale * details.scale).clamp(0.08, 12.0);
      project.view.rotation = _gestureStartRotation + details.rotation;
    });
  }

  void _handleStageTap(TapDownDetails details) {
    if (!_anchorMode || _stageSize.isEmpty) return;
    final normalized = Offset(
      details.localPosition.dx / _stageSize.width,
      details.localPosition.dy / _stageSize.height,
    );
    setState(() => _anchorTaps.add(normalized));
    if (_anchorTaps.length == 4) unawaited(_finishAnchors());
  }

  void _startAnchors() {
    final project = _project;
    if (project == null) {
      _setStatus('Import an image first');
      return;
    }
    if (_camera == null || !_camera!.value.isInitialized) {
      _setStatus('Start the camera first');
      return;
    }
    setState(() {
      _anchorMode = true;
      _anchorTaps.clear();
    });
    _setStatus(
      'Tap paper marks: top left, top right, bottom right, bottom left',
      hold: Duration.zero,
    );
  }

  Future<void> _finishAnchors() async {
    final project = _project;
    if (project == null || _anchorTaps.length != 4) return;
    setState(() => _busy = true);
    try {
      project.view.anchorQuad = List<Offset>.from(_anchorTaps);
      project.view.pinned = true;
      final frame = await _captureGrayFrame();
      project.view.anchorReferences = _anchorTaps
          .map((point) => frame.extractReference(
                frame.screenToImage(point, _stageSize),
                size: 19,
              ))
          .toList();
      await _saveCurrent(showMessage: false);
      _setStatus('Four anchors saved');
    } catch (error) {
      project.view.anchorReferences = null;
      _setStatus('Anchors set. Auto Adjust unavailable: $error',
          hold: const Duration(seconds: 4));
    } finally {
      if (mounted) {
        setState(() {
          _anchorMode = false;
          _anchorTaps.clear();
          _busy = false;
        });
      }
    }
  }

  Future<GrayFrame> _captureGrayFrame() async {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) {
      throw StateError('camera not running');
    }
    final shot = await controller.takePicture();
    final bytes = await shot.readAsBytes();
    try {
      await File(shot.path).delete();
    } catch (_) {}
    final codec = await ui.instantiateImageCodec(bytes);
    final decoded = await codec.getNextFrame();
    final image = decoded.image;
    final rgba = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (rgba == null) throw StateError('camera frame could not be decoded');
    final raw = rgba.buffer.asUint8List();
    final gray = Uint8List(image.width * image.height);
    for (var source = 0, dest = 0; dest < gray.length; source += 4, dest++) {
      gray[dest] = ((raw[source] * 77 +
                  raw[source + 1] * 150 +
                  raw[source + 2] * 29) >>
              8)
          .clamp(0, 255);
    }
    final frame = GrayFrame(image.width, image.height, gray);
    image.dispose();
    codec.dispose();
    return frame;
  }

  Future<void> _autoAdjust() async {
    final project = _project;
    if (project == null ||
        project.view.anchorQuad?.length != 4 ||
        project.view.anchorReferences?.length != 4) {
      _setStatus('Set four anchors before using Auto Adjust');
      return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    _setStatus('Refocusing and realigning...', hold: Duration.zero);
    try {
      await _refocus(lockAfter: false);
      final frame = await _captureGrayFrame();
      final adjusted = <Offset>[];
      for (var i = 0; i < 4; i++) {
        final expectedScreen = project.view.anchorQuad![i];
        final expectedImage = frame.screenToImage(expectedScreen, _stageSize);
        final found = frame.findReference(
          project.view.anchorReferences![i],
          expectedImage,
          radius: math.max(28, math.min(frame.width, frame.height) ~/ 12),
        );
        adjusted.add(frame.imageToScreen(found, _stageSize));
      }
      project.view.anchorQuad = adjusted;
      await _saveCurrent(showMessage: false);
      if (_traceMode) await _lockCurrentFocus(showMessage: false);
      _setStatus('Image realigned to the paper marks');
    } catch (error) {
      if (_traceMode) await _lockCurrentFocus(showMessage: false);
      _setStatus('Auto Adjust failed: $error', hold: const Duration(seconds: 4));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _showProjects() async {
    await _saveCurrent(showMessage: false);
    if (!mounted) return;
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111827),
      builder: (context) => ProjectSheet(
        projects: _projects,
        currentId: _project?.id,
        onDelete: (project) async {
          await _store.delete(project);
          _projects = await _store.loadAll();
        },
      ),
    );
    if (result == null) return;
    final project = await _store.load(result);
    if (project != null) await _setProject(project);
  }

  Future<void> _showRename() async {
    final project = _project;
    if (project == null) return;
    final controller = TextEditingController(text: project.name);
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Project name'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 60,
          onSubmitted: (value) => Navigator.pop(context, value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.trim().isEmpty) return;
    project.name = name.trim().substring(0, math.min(60, name.trim().length));
    await _saveCurrent(showMessage: true);
    if (mounted) setState(() {});
  }

  void _showHelp() {
    showDialog<void>(
      context: context,
      builder: (context) => const AlertDialog(
        title: Text('How to use TraceCat'),
        content: SingleChildScrollView(
          child: Text(
            'Import Image adds a photo or line drawing without changing it.\n\n'
            'Drag with one finger. Pinch with two fingers to resize and rotate. '
            'Pin the image before drawing.\n\n'
            'Refocus before aligning the image. Start Tracing locks the current '
            'focus without refocusing and hides the controls without resizing '
            'the camera preview.\n\n'
            'Set Anchors by tapping the four paper marks in this order: top left, '
            'top right, bottom right, bottom left. Auto Adjust intentionally '
            'refocuses and realigns to those marks.\n\n'
            'Projects and images stay on this phone. The app does not need an '
            'internet permission.',
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_traceMode && !_anchorMode,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_anchorMode) {
          setState(() {
            _anchorMode = false;
            _anchorTaps.clear();
          });
          _setStatus('Anchor setup canceled');
        } else if (_traceMode) {
          _exitTraceMode();
        }
      },
      child: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            _stageSize = Size(constraints.maxWidth, constraints.maxHeight);
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onScaleStart: _startGesture,
              onScaleUpdate: _updateGesture,
              onTapDown: _handleStageTap,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const ColoredBox(color: Color(0xFF111827)),
                  _cameraLayer(),
                  _templateLayer(),
                  if (_anchorMode || _project?.view.anchorQuad != null)
                    IgnorePointer(
                      child: CustomPaint(
                        painter: AnchorPainter(
                          points: _anchorMode
                              ? _anchorTaps
                              : (_project?.view.anchorQuad ?? const []),
                          active: _anchorMode,
                        ),
                      ),
                    ),
                  if (!_traceMode) ...[
                    _topControls(),
                    _statusChip(),
                    _bottomControls(),
                  ],
                  if (_traceMode) ...[
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 4,
                      left: 0,
                      child: _traceButton(
                        label: 'Lock Focus',
                        onPressed: () => _lockCurrentFocus(),
                      ),
                    ),
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 4,
                      right: 0,
                      child: _traceButton(
                        label: 'Controls',
                        onPressed: _exitTraceMode,
                      ),
                    ),
                  ],
                  if (_busy)
                    const Positioned.fill(
                      child: ColoredBox(
                        color: Color(0x33000000),
                        child: Center(child: CircularProgressIndicator()),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _cameraLayer() {
    final controller = _camera;
    if (controller == null || !controller.value.isInitialized) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Camera not running',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(
                _backCamera == null
                    ? 'No camera was found on this device.'
                    : 'Tap Start Camera and allow camera access.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }
    final previewSize = controller.value.previewSize;
    if (previewSize == null) return const SizedBox.shrink();
    return ClipRect(
      child: SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: previewSize.height,
            height: previewSize.width,
            child: CameraPreview(controller),
          ),
        ),
      ),
    );
  }

  Widget _templateLayer() {
    final project = _project;
    final image = _templateInfo;
    if (project == null || image == null || _stageSize.isEmpty) {
      return const SizedBox.shrink();
    }
    final view = project.view;
    final opacity = view.opacity.clamp(0.05, 1.0);
    final quad = view.anchorQuad;
    if (quad != null && quad.length == 4) {
      final aspect = image.width / image.height;
      const sourceWidth = 1000.0;
      final sourceHeight = sourceWidth / aspect;
      final pixels = quad
          .map((point) => Offset(
                point.dx * _stageSize.width,
                point.dy * _stageSize.height,
              ))
          .toList();
      final matrix = homographyMatrix(pixels, sourceWidth, sourceHeight);
      return IgnorePointer(
        child: Opacity(
          opacity: opacity,
          child: Transform(
            alignment: Alignment.topLeft,
            transform: matrix,
            transformHitTests: false,
            child: SizedBox(
              width: sourceWidth,
              height: sourceHeight,
              child: Image.file(File(project.imagePath), fit: BoxFit.fill),
            ),
          ),
        ),
      );
    }

    final aspect = image.width / image.height;
    final width = view.baseWidth * _stageSize.width * view.scale;
    final height = width / aspect;
    final center = Offset(
      view.centerX * _stageSize.width,
      view.centerY * _stageSize.height,
    );
    return Positioned(
      left: center.dx - width / 2,
      top: center.dy - height / 2,
      child: IgnorePointer(
        ignoring: view.pinned,
        child: Opacity(
          opacity: opacity,
          child: Transform.rotate(
            angle: view.rotation,
            child: SizedBox(
              width: width,
              height: height,
              child: Image.file(File(project.imagePath), fit: BoxFit.contain),
            ),
          ),
        ),
      ),
    );
  }

  Widget _topControls() {
    final initialized = _camera?.value.isInitialized ?? false;
    return Positioned(
      left: 10,
      right: 10,
      top: MediaQuery.paddingOf(context).top + 8,
      child: Row(
        children: [
          Expanded(
            child: FilledButton(
              onPressed: _cameraStarting ? null : _startCamera,
              child: Text(initialized ? 'Restart Camera' : 'Start Camera'),
            ),
          ),
          const SizedBox(width: 6),
          _smallButton(
            label: _torchOn ? 'Light On' : 'Light',
            active: _torchOn,
            onPressed: initialized ? _toggleTorch : null,
          ),
          const SizedBox(width: 6),
          _smallButton(
            label: 'Refocus',
            onPressed: initialized ? () => _refocus(lockAfter: true) : null,
          ),
          const SizedBox(width: 6),
          _smallButton(label: 'Help', onPressed: _showHelp),
        ],
      ),
    );
  }

  Widget _statusChip() {
    return Positioned(
      top: MediaQuery.paddingOf(context).top + 62,
      left: 20,
      right: 20,
      child: Center(
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.72),
            borderRadius: BorderRadius.circular(99),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            child: Text(
              '$_status  |  Focus: ${_focusLocked ? 'locked' : 'ready'}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
      ),
    );
  }

  Widget _bottomControls() {
    final project = _project;
    return Positioned(
      left: 8,
      right: 8,
      bottom: MediaQuery.paddingOf(context).bottom + 8,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xE6030712),
          border: Border.all(color: const Color(0x29FFFFFF)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _showRename,
                      child: Text(
                        project?.name ?? 'No image selected',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  Text(
                    _focusLocked ? 'Focus locked' : 'Focus ready',
                    style: const TextStyle(fontSize: 11, color: Colors.white70),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: _enterTraceMode,
                  child: const Text('Start Tracing',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _smallButton(
                      label: project?.view.pinned == true
                          ? 'Unpin Image'
                          : 'Pin Image',
                      active: project?.view.pinned == true,
                      onPressed: project == null
                          ? null
                          : () {
                              if (project.view.anchorQuad != null) {
                                _setStatus('The four anchors already pin the image');
                                return;
                              }
                              setState(() => project.view.pinned = !project.view.pinned);
                            },
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: _smallButton(
                      label: 'Fit Screen',
                      onPressed: project == null ? null : _fitImage,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: _smallButton(
                      label: 'Set Anchors',
                      active: project?.view.anchorQuad != null,
                      onPressed: _startAnchors,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: _smallButton(
                      label: 'Auto Adjust',
                      onPressed: _autoAdjust,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const SizedBox(width: 48, child: Text('Image', style: TextStyle(fontSize: 12))),
                  Expanded(
                    child: Slider(
                      value: project?.view.opacity ?? 0.48,
                      min: 0.05,
                      max: 1,
                      onChanged: project == null
                          ? null
                          : (value) => setState(() => project.view.opacity = value),
                    ),
                  ),
                  SizedBox(
                    width: 42,
                    child: Text(
                      '${((project?.view.opacity ?? 0.48) * 100).round()}%',
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(child: _smallButton(label: 'Import Image', onPressed: _importImage)),
                  const SizedBox(width: 5),
                  Expanded(child: _smallButton(label: 'Projects', onPressed: _showProjects)),
                  const SizedBox(width: 5),
                  Expanded(
                    child: _smallButton(
                      label: 'Save Project',
                      onPressed: project == null ? null : _saveCurrent,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: _smallButton(
                      label: 'Reset View',
                      onPressed: project == null ? null : _resetView,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _smallButton({
    required String label,
    required VoidCallback? onPressed,
    bool active = false,
  }) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(0, 42),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 7),
        backgroundColor: active ? Colors.amber : const Color(0xEF111827),
        foregroundColor: active ? const Color(0xFF111827) : Colors.white,
        textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
      ),
      child: Text(label, textAlign: TextAlign.center),
    );
  }

  Widget _traceButton({required String label, required VoidCallback onPressed}) {
    return FilledButton.tonal(
      onPressed: onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: const Color(0x7A030712),
        foregroundColor: Colors.white70,
        minimumSize: const Size(0, 36),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(9)),
        ),
      ),
      child: Text(label, style: const TextStyle(fontSize: 12)),
    );
  }
}

class ProjectSheet extends StatefulWidget {
  const ProjectSheet({
    super.key,
    required this.projects,
    required this.currentId,
    required this.onDelete,
  });

  final List<TraceProject> projects;
  final String? currentId;
  final Future<void> Function(TraceProject project) onDelete;

  @override
  State<ProjectSheet> createState() => _ProjectSheetState();
}

class _ProjectSheetState extends State<ProjectSheet> {
  late List<TraceProject> projects = List<TraceProject>.from(widget.projects);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Saved projects',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: projects.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (context, index) {
                  final project = projects[index];
                  final current = project.id == widget.currentId;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Image.file(
                        File(project.imagePath),
                        width: 56,
                        height: 64,
                        fit: BoxFit.contain,
                      ),
                    ),
                    title: Text(project.name,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                      DateTime.fromMillisecondsSinceEpoch(project.modified)
                          .toLocal()
                          .toString()
                          .split('.').first,
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: current
                              ? null
                              : () => Navigator.pop(context, project.id),
                          child: Text(current ? 'Current' : 'Open'),
                        ),
                        IconButton(
                          tooltip: 'Delete',
                          onPressed: current
                              ? null
                              : () async {
                                  await widget.onDelete(project);
                                  setState(() => projects.remove(project));
                                },
                          icon: const Icon(Icons.delete_outline),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AnchorPainter extends CustomPainter {
  AnchorPainter({required this.points, required this.active});

  final List<Offset> points;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    final pixels = points
        .map((point) => Offset(point.dx * size.width, point.dy * size.height))
        .toList();
    final line = Paint()
      ..color = Colors.amber.withValues(alpha: 0.9)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    if (pixels.length > 1) {
      final path = Path()..moveTo(pixels.first.dx, pixels.first.dy);
      for (final point in pixels.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }
      if (!active && pixels.length == 4) path.close();
      canvas.drawPath(path, line);
    }
    for (final point in pixels) {
      canvas.drawCircle(point, 13, Paint()..color = const Color(0x66000000));
      canvas.drawCircle(point, 12, line..strokeWidth = 3);
      canvas.drawLine(point - const Offset(8, 0), point + const Offset(8, 0), line);
      canvas.drawLine(point - const Offset(0, 8), point + const Offset(0, 8), line);
    }
  }

  @override
  bool shouldRepaint(covariant AnchorPainter oldDelegate) =>
      oldDelegate.points != points || oldDelegate.active != active;
}

class ProjectStore {
  static const _currentKey = 'tracecat_flutter_current_project';
  late Directory _projectsDirectory;
  late SharedPreferences _preferences;

  Future<void> initialize() async {
    final documents = await getApplicationDocumentsDirectory();
    _projectsDirectory = Directory('${documents.path}/tracecat/projects');
    await _projectsDirectory.create(recursive: true);
    _preferences = await SharedPreferences.getInstance();
  }

  Future<TraceProject> createFromImport(File source) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = 'project-$now';
    final directory = Directory('${_projectsDirectory.path}/$id');
    await directory.create(recursive: true);
    final extension = source.path.contains('.')
        ? source.path.substring(source.path.lastIndexOf('.')).toLowerCase()
        : '.jpg';
    final destination = File('${directory.path}/image$extension');
    await source.copy(destination.path);
    final filename = source.uri.pathSegments.isEmpty
        ? 'Imported image'
        : source.uri.pathSegments.last;
    final dot = filename.lastIndexOf('.');
    final name = (dot > 0 ? filename.substring(0, dot) : filename).trim();
    final project = TraceProject(
      id: id,
      name: name.isEmpty ? 'Imported project' : name,
      imagePath: destination.path,
      created: now,
      modified: now,
      view: TraceView(),
    );
    await save(project);
    await setCurrent(id);
    return project;
  }

  Future<void> save(TraceProject project) async {
    project.modified = DateTime.now().millisecondsSinceEpoch;
    final directory = Directory('${_projectsDirectory.path}/${project.id}');
    await directory.create(recursive: true);
    final file = File('${directory.path}/project.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(project.toJson()));
  }

  Future<TraceProject?> load(String id) async {
    final file = File('${_projectsDirectory.path}/$id/project.json');
    if (!await file.exists()) return null;
    try {
      return TraceProject.fromJson(jsonDecode(await file.readAsString()) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<List<TraceProject>> loadAll() async {
    final projects = <TraceProject>[];
    if (!await _projectsDirectory.exists()) return projects;
    await for (final entity in _projectsDirectory.list()) {
      if (entity is! Directory) continue;
      final id = entity.uri.pathSegments.where((segment) => segment.isNotEmpty).last;
      final project = await load(id);
      if (project != null && await File(project.imagePath).exists()) projects.add(project);
    }
    projects.sort((a, b) => b.modified.compareTo(a.modified));
    return projects;
  }

  Future<void> delete(TraceProject project) async {
    final directory = Directory('${_projectsDirectory.path}/${project.id}');
    if (await directory.exists()) await directory.delete(recursive: true);
  }

  Future<void> setCurrent(String id) => _preferences.setString(_currentKey, id);

  Future<TraceProject?> loadCurrent() async {
    final id = _preferences.getString(_currentKey);
    if (id == null) return null;
    return load(id);
  }
}

class TraceProject {
  TraceProject({
    required this.id,
    required this.name,
    required this.imagePath,
    required this.created,
    required this.modified,
    required this.view,
  });

  final String id;
  String name;
  final String imagePath;
  final int created;
  int modified;
  final TraceView view;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'imagePath': imagePath,
        'created': created,
        'modified': modified,
        'view': view.toJson(),
      };

  factory TraceProject.fromJson(Map<String, dynamic> json) => TraceProject(
        id: json['id'] as String,
        name: json['name'] as String? ?? 'Untitled project',
        imagePath: json['imagePath'] as String,
        created: json['created'] as int? ?? DateTime.now().millisecondsSinceEpoch,
        modified: json['modified'] as int? ?? DateTime.now().millisecondsSinceEpoch,
        view: TraceView.fromJson(json['view'] as Map<String, dynamic>? ?? const {}),
      );
}

class TraceView {
  double centerX = 0.5;
  double centerY = 0.5;
  double baseWidth = 0.72;
  double scale = 1;
  double rotation = 0;
  double opacity = 0.48;
  bool pinned = false;
  List<Offset>? anchorQuad;
  List<AnchorReference>? anchorReferences;

  Map<String, dynamic> toJson() => {
        'centerX': centerX,
        'centerY': centerY,
        'baseWidth': baseWidth,
        'scale': scale,
        'rotation': rotation,
        'opacity': opacity,
        'pinned': pinned,
        'anchorQuad': anchorQuad
            ?.map((point) => {'x': point.dx, 'y': point.dy})
            .toList(),
        'anchorReferences': anchorReferences?.map((ref) => ref.toJson()).toList(),
      };

  factory TraceView.fromJson(Map<String, dynamic> json) {
    final view = TraceView()
      ..centerX = (json['centerX'] as num?)?.toDouble() ?? 0.5
      ..centerY = (json['centerY'] as num?)?.toDouble() ?? 0.5
      ..baseWidth = (json['baseWidth'] as num?)?.toDouble() ?? 0.72
      ..scale = (json['scale'] as num?)?.toDouble() ?? 1
      ..rotation = (json['rotation'] as num?)?.toDouble() ?? 0
      ..opacity = (json['opacity'] as num?)?.toDouble() ?? 0.48
      ..pinned = json['pinned'] as bool? ?? false;
    final quad = json['anchorQuad'] as List<dynamic>?;
    if (quad != null && quad.length == 4) {
      view.anchorQuad = quad
          .map((item) => item as Map<String, dynamic>)
          .map((item) => Offset(
                (item['x'] as num).toDouble(),
                (item['y'] as num).toDouble(),
              ))
          .toList();
    }
    final references = json['anchorReferences'] as List<dynamic>?;
    if (references != null && references.length == 4) {
      view.anchorReferences = references
          .map((item) => AnchorReference.fromJson(item as Map<String, dynamic>))
          .toList();
    }
    return view;
  }
}

class AnchorReference {
  const AnchorReference({required this.size, required this.bytes});

  final int size;
  final Uint8List bytes;

  Map<String, dynamic> toJson() => {
        'size': size,
        'bytes': base64Encode(bytes),
      };

  factory AnchorReference.fromJson(Map<String, dynamic> json) => AnchorReference(
        size: json['size'] as int,
        bytes: base64Decode(json['bytes'] as String),
      );
}

class GrayFrame {
  GrayFrame(this.width, this.height, this.gray);

  final int width;
  final int height;
  final Uint8List gray;

  Offset screenToImage(Offset normalizedScreen, Size screenSize) {
    final scale = math.max(screenSize.width / width, screenSize.height / height);
    final renderedWidth = width * scale;
    final renderedHeight = height * scale;
    final offsetX = (screenSize.width - renderedWidth) / 2;
    final offsetY = (screenSize.height - renderedHeight) / 2;
    final screen = Offset(
      normalizedScreen.dx * screenSize.width,
      normalizedScreen.dy * screenSize.height,
    );
    return Offset(
      ((screen.dx - offsetX) / scale).clamp(0, width - 1),
      ((screen.dy - offsetY) / scale).clamp(0, height - 1),
    );
  }

  Offset imageToScreen(Offset imagePoint, Size screenSize) {
    final scale = math.max(screenSize.width / width, screenSize.height / height);
    final renderedWidth = width * scale;
    final renderedHeight = height * scale;
    final offsetX = (screenSize.width - renderedWidth) / 2;
    final offsetY = (screenSize.height - renderedHeight) / 2;
    return Offset(
      (imagePoint.dx * scale + offsetX) / screenSize.width,
      (imagePoint.dy * scale + offsetY) / screenSize.height,
    );
  }

  AnchorReference extractReference(Offset center, {required int size}) {
    final half = size ~/ 2;
    final bytes = Uint8List(size * size);
    for (var y = 0; y < size; y++) {
      for (var x = 0; x < size; x++) {
        final sourceX = (center.dx.round() + x - half).clamp(0, width - 1);
        final sourceY = (center.dy.round() + y - half).clamp(0, height - 1);
        bytes[y * size + x] = gray[sourceY * width + sourceX];
      }
    }
    return AnchorReference(size: size, bytes: bytes);
  }

  Offset findReference(
    AnchorReference reference,
    Offset expected, {
    required int radius,
  }) {
    var bestScore = -2.0;
    var best = expected;
    final step = math.max(1, radius ~/ 35);
    for (var y = expected.dy.round() - radius;
        y <= expected.dy.round() + radius;
        y += step) {
      if (y < 0 || y >= height) continue;
      for (var x = expected.dx.round() - radius;
          x <= expected.dx.round() + radius;
          x += step) {
        if (x < 0 || x >= width) continue;
        final score = _correlation(reference, x, y);
        if (score > bestScore) {
          bestScore = score;
          best = Offset(x.toDouble(), y.toDouble());
        }
      }
    }
    if (bestScore < 0.42) {
      throw StateError('paper marks were not clear enough');
    }
    return best;
  }

  double _correlation(AnchorReference reference, int centerX, int centerY) {
    final size = reference.size;
    final half = size ~/ 2;
    var referenceMean = 0.0;
    var candidateMean = 0.0;
    for (var i = 0; i < reference.bytes.length; i++) {
      referenceMean += reference.bytes[i];
      final x = i % size;
      final y = i ~/ size;
      final sourceX = (centerX + x - half).clamp(0, width - 1);
      final sourceY = (centerY + y - half).clamp(0, height - 1);
      candidateMean += gray[sourceY * width + sourceX];
    }
    referenceMean /= reference.bytes.length;
    candidateMean /= reference.bytes.length;
    var numerator = 0.0;
    var referenceNorm = 0.0;
    var candidateNorm = 0.0;
    for (var i = 0; i < reference.bytes.length; i++) {
      final x = i % size;
      final y = i ~/ size;
      final sourceX = (centerX + x - half).clamp(0, width - 1);
      final sourceY = (centerY + y - half).clamp(0, height - 1);
      final a = reference.bytes[i] - referenceMean;
      final b = gray[sourceY * width + sourceX] - candidateMean;
      numerator += a * b;
      referenceNorm += a * a;
      candidateNorm += b * b;
    }
    final denominator = math.sqrt(referenceNorm * candidateNorm);
    return denominator < 1e-9 ? -1 : numerator / denominator;
  }
}

Matrix4 homographyMatrix(List<Offset> quad, double sourceWidth, double sourceHeight) {
  final p0 = quad[0];
  final p1 = quad[1];
  final p2 = quad[2];
  final p3 = quad[3];
  final dx1 = p1.dx - p2.dx;
  final dx2 = p3.dx - p2.dx;
  final dx3 = p0.dx - p1.dx + p2.dx - p3.dx;
  final dy1 = p1.dy - p2.dy;
  final dy2 = p3.dy - p2.dy;
  final dy3 = p0.dy - p1.dy + p2.dy - p3.dy;
  final det = dx1 * dy2 - dx2 * dy1;

  late double a, b, c, d, e, f, g, h;
  if (dx3.abs() < 1e-6 && dy3.abs() < 1e-6) {
    a = p1.dx - p0.dx;
    b = p3.dx - p0.dx;
    c = p0.dx;
    d = p1.dy - p0.dy;
    e = p3.dy - p0.dy;
    f = p0.dy;
    g = 0;
    h = 0;
  } else if (det.abs() < 1e-6) {
    return Matrix4.identity();
  } else {
    g = (dx3 * dy2 - dx2 * dy3) / det;
    h = (dx1 * dy3 - dx3 * dy1) / det;
    a = p1.dx - p0.dx + g * p1.dx;
    b = p3.dx - p0.dx + h * p3.dx;
    c = p0.dx;
    d = p1.dy - p0.dy + g * p1.dy;
    e = p3.dy - p0.dy + h * p3.dy;
    f = p0.dy;
  }

  return Matrix4.fromList([
    a / sourceWidth,
    d / sourceWidth,
    0,
    g / sourceWidth,
    b / sourceHeight,
    e / sourceHeight,
    0,
    h / sourceHeight,
    0,
    0,
    1,
    0,
    c,
    f,
    0,
    1,
  ]);
}
