# TraceCat Flutter

TraceCat rebuilt as a native Flutter camera-overlay app.

## Included

- Imports images without modifying them
- Camera preview through Flutter's CameraX-backed camera plugin on Android
- Refocus, focus lock, and flashlight controls
- Drag, pinch-resize, rotate, opacity, and image pinning
- A trace mode that hides controls without changing preview dimensions
- Four-corner paper anchors and local Auto Adjust matching
- Local saved projects
- No internet permission
- Screen stays awake while the app runs

## Android support

The project uses Android minSdk 24, which means Android 7.0 and newer. The package name is `com.tracecat.flutter`, so it installs beside the older WebView TraceCat builds.

## Build

1. Install Flutter 3.44 or newer and an Android SDK.
2. Run `flutter pub get`.
3. Run `flutter test`.
4. For a test APK, run `flutter build apk --debug`.
5. For a signed APK, place `key.properties` and `app/tracecat-release.jks` in the `android` folder, then run `flutter build apk --release`.

The output APK appears at `build/app/outputs/flutter-apk/app-release.apk`.

## Focus behavior

`Refocus` switches the camera to automatic focus, waits for it to settle, then locks it. `Start Tracing` does not trigger autofocus. It only applies the locked focus mode and hides overlay controls. The camera preview stays in the same full-screen layout before and after Start Tracing.

Some phone lenses physically change their field of view while focusing. Software cannot remove that optical lens breathing. Align the image only after pressing Refocus.

## Auto Adjust

Set Anchors captures reference patches around four marks on the paper. Auto Adjust deliberately refocuses, captures a frame, searches near each saved mark, and updates the image quadrilateral. Test this on several phone models because camera JPEG orientation and crop behavior vary by manufacturer.
